import React from 'react'

export const Clients = () => {
  return (
    <div>Clients</div>
  )
}
export default Clients;
