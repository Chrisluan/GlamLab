import React from 'react'

const Professionals = () => {
  return (
    <div>Professionals</div>
  )
}
export default Professionals