import React from 'react'

export const Finances = () => {
  return (
    <div>Finances</div>
  )
}
export default Finances
