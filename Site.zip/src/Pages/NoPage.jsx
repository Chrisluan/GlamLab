import { Heading } from "@chakra-ui/react";
const NoPage = ({page}) => <Heading>Página {page} não encontrada</Heading>;
export default NoPage;