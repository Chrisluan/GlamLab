import React from 'react'

export const Appointments = () => {
  return (
    <div>Appointments</div>
  )
}
