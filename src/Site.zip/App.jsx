import { useContext, useState } from "react";
import { NavigationContext } from "./Context/NavigationContext";
import { Button, Flex, Heading,Box } from "@chakra-ui/react";
import Sidebar from "./Components/Sidebar/Sidebar";
import { ContentContainer } from "./Components/Content/ContentContainer";
function App() {
  const { paginaAtual } = useContext(NavigationContext);

  return (
    <Flex height={"100dvh"}>
      <Sidebar />
      <ContentContainer>
        <Flex
          sx={{
            width: "100%",
            background: "#f6f6f6",
            padding: 2,
            borderRadius: "lg",
          }}
        >
          <Box>
            <Heading>{paginaAtual.title}</Heading>
          </Box>
        </Flex>
      </ContentContainer>
    </Flex>
  );
}

export default App;
