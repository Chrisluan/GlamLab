import { createContext, useState, useCallback } from 'react';
import options from "../Components/Sidebar/configs/Options.json"
// Criar o Contexto
const NavigationContext = createContext();

// Criar o Provedor do Contexto
const NavigationProvider = ({ children }) => {
  const defaultOption = options.find(option => option.isDefault === true);
  const [paginaAtual, setPaginaAtual] = useState(defaultOption.page !== "" ? defaultOption : "no-page");

  // 1. CRIE A FUNÇÃO QUE RECEBE A STRING
  // Esta função será disponibilizada para os componentes filhos.
  const mudarPagina = (novaPagina) => {
    // Você pode adicionar lógicas aqui, como verificar se a página existe
    console.log(`Mudando para a página: ${novaPagina}`);
    setPaginaAtual(options.find(op => op.page === novaPagina));
  };

  // Otimização: Usar useCallback para evitar recriações desnecessárias da função.
  // const mudarPagina = useCallback((novaPagina) => {
  //   setPaginaAtual(novaPagina);
  // }, []);

  return (
    // 2. FORNEÇA A FUNÇÃO E O ESTADO NO CONTEXTO
    <NavigationContext.Provider value={{ paginaAtual, mudarPagina }}>
      {children}
    </NavigationContext.Provider>
  );
};

export { NavigationContext, NavigationProvider, options };